// ضع إعدادات مشروع Firebase هنا بعد إنشائه من Firebase Console.
// هذا الملف ليس مكانًا لكلمات مرور الأدمن؛ إعدادات الويب العامة لا تمنح صلاحية كتابة دون قواعد أمان صحيحة.
export const firebaseConfig = {
  apiKey: "PASTE_YOUR_FIREBASE_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.firebasestorage.app",
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  appId: "YOUR_FIREBASE_APP_ID"
};
// بعد إنشاء حساب الأدمن، أضف UID الخاص به هنا، وأضف UID نفسه إلى قواعد Firestore وStorage.
export const adminUids = [
  // "PASTE_ADMIN_AUTH_UID_HERE"
];
